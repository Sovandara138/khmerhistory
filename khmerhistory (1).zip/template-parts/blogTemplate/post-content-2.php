<?php $skip_min_height = false; ?><section class="u-clearfix u-section-2" id="sec-4be3">
  <div class="u-clearfix u-sheet u-sheet-1"></div>
</section><?php if ($skip_min_height) { echo "<style> .u-section-2, .u-section-2 .u-sheet {min-height: auto;}</style>"; } ?>