<!-- header styles -->

<link id="u-google-font" rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i">
<style>.u-header {
  background-image: none;
}
.u-header .u-sheet-1 {
  min-height: 100px;
}
.u-header .u-menu-1 {
  margin: 34px 0 0 auto;
}
.u-header .u-nav-1 {
  font-size: 1rem;
  letter-spacing: 0px;
  font-weight: 700;
  text-transform: uppercase;
}
.u-block-a106-23 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
.u-header .u-nav-2 {
  font-size: 1.25rem;
}
.u-block-a106-24 {
  box-shadow: 2px 2px 8px 0 rgba(128,128,128,1);
}
.u-header .u-text-1 {
  margin: -32px 869px 0 0;
}
.u-header .u-text-2 {
  margin: -25px 655px 34px 245px;
}
@media (max-width: 1199px) {
  .u-header .u-menu-1 {
    width: auto;
  }
  .u-header .u-text-1 {
    margin-top: -32px;
    margin-right: 669px;
  }
  .u-header .u-text-2 {
    width: auto;
    margin-right: 457px;
    margin-left: 243px;
  }
}
@media (max-width: 991px) {
  .u-header .u-text-1 {
    margin-right: 449px;
  }
  .u-header .u-text-2 {
    margin: 0 480px 9px 0;
  }
}
@media (max-width: 767px) {
  .u-header .u-text-1 {
    margin-right: 269px;
  }
  .u-header .u-text-2 {
    margin-right: 300px;
  }
}
@media (max-width: 575px) {
  .u-header .u-text-1 {
    margin-right: 69px;
  }
  .u-header .u-text-2 {
    margin-right: 100px;
    margin-bottom: 17px;
  }
}</style>
